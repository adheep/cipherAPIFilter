import { Component } from '@angular/core';
import { PatientFormComponent } from './patient-form/patient-form.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [PatientFormComponent],
  template: '<app-patient-form></app-patient-form>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'patient-form-app';
}
