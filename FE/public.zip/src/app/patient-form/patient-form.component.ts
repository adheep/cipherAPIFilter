import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-patient-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './patient-form.component.html',
  styleUrls: ['./patient-form.component.css']
})
export class PatientFormComponent {
  patientForm: FormGroup;
  responseMessage: string | null = null;
  
  secretKey = 'walg-16-byte-key'; // Replace with your actual secret key
  
  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.patientForm = this.fb.group({
      name: [''],
      age: [''],
      address: ['']
    });
  }

  async encryptData(data: any): Promise<string> {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(this.secretKey);
    const key = await crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'AES-ECB' },
      false,
      ['encrypt']
    );

    const encodedData = encoder.encode(JSON.stringify(data));
    const paddedData = this.padData(encodedData);
    const encryptedData = await crypto.subtle.encrypt(
      { name: 'AES-ECB' },
      key,
      paddedData
    );

    return btoa(String.fromCharCode(...new Uint8Array(encryptedData)));
  }

  async decryptData(encryptedData: string): Promise<any> {
    const encryptedBytes = Uint8Array.from(atob(encryptedData), c => c.charCodeAt(0));

    const keyData = new TextEncoder().encode(this.secretKey);
    const key = await crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'AES-ECB' },
      false,
      ['decrypt']
    );

    const decryptedData = await crypto.subtle.decrypt(
      { name: 'AES-ECB' },
      key,
      encryptedBytes
    );

    const unpaddedData = this.unpadData(new Uint8Array(decryptedData));
    return JSON.parse(new TextDecoder().decode(unpaddedData));
  }

  padData(data: Uint8Array): Uint8Array {
    const blockSize = 16;
    const padding = blockSize - (data.length % blockSize);
    const paddedData = new Uint8Array(data.length + padding);
    paddedData.set(data);
    paddedData.fill(padding, data.length);
    return paddedData;
  }

  unpadData(data: Uint8Array): Uint8Array {
    const padding = data[data.length - 1];
    return data.slice(0, data.length - padding);
  }

  async onSubmit() {
    const formData = this.patientForm.value;
    const encryptedData = await this.encryptData(formData);
    const headers = { 'Content-Type': 'application/com.arxdig.api.e2+json' };

    this.http.post('http://localhost:8081/patients', { data: encryptedData }, { headers, responseType: 'text' })
      .subscribe(async response => {
        console.log('API response', response);
        const responseData = JSON.parse(response).data;
        const decryptedResponse = await this.decryptData(responseData);
        console.log('Decrypted response', decryptedResponse);
        this.responseMessage = decryptedResponse.message;
      }, error => {
        console.error('API error', error);
        alert('Failed to submit form.');
      });
  }
}